package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.CancionDAO;
import SongLists.DAO.DiscoDAO;
import SongLists.model.Cancion;
import SongLists.model.Disco;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;

public class E_CancionController {
//3 textfield 1 choicebox
	static CancionDAO cd = new CancionDAO();
	static List<Disco> Alldisc = DiscoDAO.mostrarTodos();
	static String direccionurl = "src/main/resources/Imagenes/portadas/";
	static String camposFaltantes = "";
	
	@FXML
	private TextField nombretext;
	@FXML
	private TextField duraciontext;
	@FXML
	private TextField Generotext;
	@FXML
	private ComboBox<String> Discosbox;
	@FXML
	private ComboBox<String> nombrebox;
	
	@FXML
	private void initialize() {
		ObservableList<String>listaDiscos=FXCollections.observableArrayList(nombresDiscos(Alldisc));
		Discosbox.setValue(listaDiscos.get(0));
		Discosbox.setItems(listaDiscos);
		if(Alldisc.size()>3) {
			Discosbox.setVisibleRowCount(3);
		}
		ObservableList<String> listaNombres= FXCollections.observableArrayList(nombres((CancionDAO.mostrarTodos())));
		nombrebox.setValue(listaNombres.get(0));
		nombrebox.setItems(listaNombres);
		if((DiscoDAO.mostrarTodos()).size()>3) {
			nombrebox.setVisibleRowCount(3);
		}
	}
	private ArrayList<String>nombres(List<Cancion> d){
		ArrayList<String> nombres= new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			nombres.add(d.get(i).getNombre());
		}
		return nombres;
	}
	private boolean validarFormulario() {
		boolean result = true;
		if (nombretext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "Nombre\n";
		}

		if (duraciontext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "Duracion\n";
		}
		if (Generotext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "genero\n";
		}
		if (Discosbox.getSelectionModel().getSelectedItem() == null) {
			result = false;
			camposFaltantes += "Disco\n";
		}
		// en caso de faltar algo muestra un aviso
		if (result == false) {
			mostrarAlert();
		}
		cd.guardar();
		return result;
	}

	@FXML
	private void agregar() throws IOException {

		try {
			if (!validarFormulario())
				return;
			cd.setNombre(nombretext.getText());
			cd.setDuracion(Integer.parseInt(duraciontext.getText()));
			cd.setGenero(Generotext.getText());
			cd.setId_Disco(DiscoDAO.mostrarPorNombre(Discosbox.getSelectionModel().getSelectedItem()));
			mostrarAlertInfo();
			Utils.tipopestaña = "todos";
			App.setRoot("C_Cancion");
			
		} catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		cd.setId(CancionDAO.mostrarPorNombre(nombrebox.getValue()).getId());
		cd.editar();
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
		
		
	}
	private ArrayList<String>nombresDiscos(List<Disco> d){
		ArrayList<String> artistas= new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			artistas.add(d.get(i).getNombre());
		}
		return artistas;
	}
	@FXML
	private void Cancel() throws IOException {
		Utils.tipopestaña = "todos";
		App.setRoot("V_Cancion");
	}
	
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}

	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Artista guardado");
		alert.showAndWait();
	}

}
