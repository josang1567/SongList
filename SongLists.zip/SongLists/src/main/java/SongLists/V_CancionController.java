package SongLists;

import javafx.fxml.FXML;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.CancionDAO;
import SongLists.DAO.ListaDAO;
import SongLists.model.Cancion;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;

public class V_CancionController {

	static CancionDAO cancion = new CancionDAO();
	static List<Cancion> canciones = new ArrayList<Cancion>();
	@FXML
	private Label nombre;
	@FXML
	private Label duracion;
	@FXML
	private Label genero;
	@FXML
	private Label Numero_reproducciones;
	@FXML
	private Label id;
	@FXML
	private Label id_disco;
	@FXML
	private TableView<Cancion> tablaArtistas;
	@FXML
	private TableColumn<Cancion, String> ArtistaColumna;
	@FXML
	private Menu menu;
	@FXML
	protected void initialize() {
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
		List<Cancion> Listado = new ArrayList<Cancion>();
		muestraInfo(null);
		configuraTabla();
		switch (Utils.tipopestaña) {
		case "todos":
			Listado = CancionDAO.mostrarTodos();
			break;
		case "ID":
			Listado.add(CancionDAO.mostrarPorId((int) Utils.dato));
			break;
		case "nombre":
			Listado.add(CancionDAO.mostrarPorNombre((String) Utils.dato));
			break;
		case"lista":
			System.out.println(Utils.dato);
			Listado=CancionDAO.Mostrar_favoritos((int)Utils.dato);
			break;
		default:
			break;

		}
		tablaArtistas.setItems(FXCollections.observableArrayList(Listado));
		tablaArtistas.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			muestraInfo(newValue);
		});
	}

	private void muestraInfo(Cancion a) {
		if (a != null) {
			nombre.setText(a.getNombre());
			duracion.setText(String.valueOf(a.getDuracion()));
			genero.setText(a.getGenero());
			Numero_reproducciones.setText(String.valueOf(a.getN_reproducciones()));
			id.setText(String.valueOf(a.getId()));
			id_disco.setText(String.valueOf(a.getId_Disco().getId()));
		
		} else {
			nombre.setText("Desconocido");
			duracion.setText("Desconocido");
			genero.setText("Desconocido");
			Numero_reproducciones.setText("Desconocido");
			id.setText("Desconocido");
			id_disco.setText("Desconocido");
		}
	}

	private void configuraTabla() {
		ArtistaColumna.setCellValueFactory(cadaArtista -> {
			SimpleStringProperty v = new SimpleStringProperty();
			v.setValue(cadaArtista.getValue().getNombre());
			return v;
		});

	}
	
	@FXML
	private void ir_a_añadir_lista() throws IOException{
		Utils.dato=id.getText();
		App.setRoot("AgregarALista");
	}
	
	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("E_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("V_Usuarios");
	}
	@FXML
	private void eliminar() throws IOException {
		cancion.borrar();
		App.setRoot("V_Artista");
	}

}
