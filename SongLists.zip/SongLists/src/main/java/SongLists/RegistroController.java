package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import SongList.Utils.Utils;
import SongLists.DAO.UsuarioDAO;
import SongLists.model.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class RegistroController {
	
	static UsuarioDAO nuevo = new UsuarioDAO();
	static List<Usuario> todosUsuarios = UsuarioDAO.mostrarTodos();
	static String direccionurl = "src/main/resources/Imagenes/portadas/";
	static String camposFaltantes = "";
	@FXML
	private TextField nombretext;
	@FXML
	private PasswordField Contraseñatext;
	@FXML
	private TextField Correotext;
	@FXML
	private TextField urltext;
	@FXML
	private Button seleccionarFoto;
	@FXML
	private ImageView fotoview;
	@FXML
	private void initialize() {
		if (urltext.getText().trim().equals("")) {
			urltext.setText("../Imagenes/Logo/634741.png");
		}
	}

	private boolean validarFormulario() {
		boolean result = true;
		if (nombretext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "Nombre\n";
		}

		if (Contraseñatext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "Duracion\n";
		}
		if (Correotext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "genero\n";
		}
		if(comprobarCorreo(Correotext.getText())==false) {
			mostrarAlertEmail();
			result = false;
		}
		if(comprobarExistencia(nuevo)==true) {
			mostrarAlertUsuario();
			result=false;
		}

		// en caso de faltar algo muestra un aviso
		if (result == false) {
			mostrarAlert();
		}
		
		return result;
	}

	@FXML
	private void agregar() throws IOException {
		try {
			if(!validarFormulario())
				return;
			nuevo.setNombre(nombretext.getText());
			nuevo.setContraseña(Contraseñatext.getText());
			nuevo.setCorreo(Correotext.getText());
			Utils.saveImage(urltext.getText(), direccionurl + nuevo.getNombre());
			nuevo.setFoto(direccionurl);
			
			
		} catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		nuevo.guardar();
		mostrarAlertInfo();
		Utils.tipopestaña = "todos";
		App.setRoot("Login");
	}
	private boolean comprobarCorreo(String email) {
		boolean correcto=false;
		 Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
	                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
	 
	        // El email a validar
	        Matcher mather = pattern.matcher(email);
	 
	        if (mather.find() == true) {
	           correcto=true;
	        } else {
	        	correcto=false;
	        }
		return correcto;
	}
	private boolean comprobarExistencia(Usuario usuario) {
		boolean existe=false;
		
		for (int i = 0; i < todosUsuarios.size()&&existe; i++) {
			if(usuario==todosUsuarios.get(i)) {
				existe=true;
			}
		}
		return existe;
	}
	@FXML
	private void selecImagen() {
		File file = null;
		FileChooser filechooser = new FileChooser();
		filechooser.setTitle("Selecionar imagen...");
		try {
			file = filechooser.showOpenDialog(null);
			if (file != null && file.getPath().matches(".+\\.png") || file.getPath().matches(".+\\.jpg")) {
				Image img = new Image("file:\\" + file.getPath());
				fotoview.setImage(img);
				urltext.setText(file.getPath());
			} else { // si la extension es incorrecta sale esta alerta
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Información");
				alert.setContentText("Formato incorrecto: Debe elegir un tipo de archivo jpg o png.");
				alert.showAndWait();
			}
		} catch (Exception e) {
			// TODO: handle exception;
		}
	}
	
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}

	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Usuario guardado");
		alert.showAndWait();
	}
	private void mostrarAlertEmail() {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Correo no valido");
		alert.showAndWait();
	}
	private void mostrarAlertUsuario() {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("El usuario ya existe");
		alert.showAndWait();
	}

	
}