package SongLists.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import SongList.Utils.MariaDBConexion;
import SongLists.model.Lista_cancion;

public class Lista_cancionDAO extends Lista_cancion {

	private static final String INSERT = "INSERT INTO lista-cancion(Nombre_Lista, Id_Lista, Nombre_disco, Id_disco) VALUES (?,?,?,?)";

	private static final String MOSTRARTODOS = "SELECT Nombre_Lista, Id_Lista, Nombre_cancion, Id_cancion FROM lista-cancion ";
	private static final String MOSTRARPORNOMBRE = "SELECT Nombre_Lista, Id_Lista, Nombre_cancion, Id_cancion FROM lista-cancion WHERE Nombre_Lista=?";
	private static final String MOSTRARPORIDLISTA = "SELECT Nombre_Lista, Id_Lista, Nombre_cancion, Id_cancion FROM lista-cancion WHERE Id_Lista=?";
	private static final String MOSTRARPORIDCANCION = "SELECT Nombre_Lista, Id_Lista, Nombre_cancion, Id_cancion FROM lista-cancion WHERE Id_cancion=?";

	private static final String EDITAR = "UPDATE `lista-cancion` SET `Nombre_Lista`=?,`Id_Lista`=?,`Nombre_cancion`=?,`Id_cancion`=? WHERE Id_cancion=?";
	private static final String BORRAR = "DELETE FROM `lista-cancion` WHERE Id_cancion=?";
	private static Connection con = null;
	
	public Lista_cancionDAO(String nombre_Lista, String nombre_cancion, int id_Lista, int id_cancion) {
		super(nombre_Lista, nombre_cancion, id_Lista, id_cancion);
		// TODO Auto-generated constructor stub
	}

	public Lista_cancionDAO(Lista_cancion ld) {
		super(ld.getNombre_Lista(), ld.getNombre_cancion(),  ld.getId_Lista(), ld.getId_cancion());
	}
	public Lista_cancionDAO() {
		super();
		}
	public void guardar() {

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
		
			try {
				ps = con.prepareStatement(INSERT);

				ps.setString(1, this.Nombre_Lista);
				ps.setInt(2, this.Id_Lista);
				ps.setString(3, this.Nombre_cancion);
				ps.setInt(4, this.Id_cancion);
				ps.executeUpdate();
				
				
				// fin de extraer el id generado automaticamente en la db
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void editar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(EDITAR);

				ps.setString(1, this.Nombre_Lista);
				ps.setInt(2, this.Id_Lista);
				ps.setString(3, this.Nombre_cancion);
				ps.setInt(4, this.Id_cancion);

				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void borrar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(BORRAR);
				ps.setInt(1, this.Id_cancion);
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public static List<Lista_cancion> mostrarTodos() {
		List<Lista_cancion> resultado = new ArrayList<Lista_cancion>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARTODOS);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new Lista_cancion(

							rs.getString("Nombre_Lista"),
							rs.getString("Nombre_cancion"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}

	public static Lista_cancion mostrarPorNombre(String nombre) {
		Lista_cancion resultado = new Lista_cancion();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORNOMBRE);
				ps.setString(1, nombre);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado=new Lista_cancion(

							rs.getString("Nombre_Lista"),
							rs.getString("Nombre_cancion"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	
	}

	public static  List<Lista_cancion> mostrarPorIdlista(int id) {
		List<Lista_cancion> resultado= new  ArrayList<Lista_cancion>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORIDLISTA);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new Lista_cancion(

							rs.getString("Nombre_Lista"),
							rs.getString("Nombre_cancion"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}
	
	
	public static  Lista_cancion mostrarPorIdcancion(int id) {
		Lista_cancion resultado = new Lista_cancion();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORIDCANCION);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado=new Lista_cancion(

							rs.getString("Nombre_Lista"),
							rs.getString("Nombre_cancion"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}
	
}
