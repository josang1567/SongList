package SongLists.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.MariaDBConexion;
import SongLists.model.Artista;
import SongLists.model.Disco;

public class DiscoDAO extends Disco {
	private static final String INSERT = "INSERT INTO disco "
			+ "(Nombre, fechaPublicacion, Foto, NumeroReproducciones, Id_artista ) VALUES (?,?,?,?,?)";

	private static final String MOSTRARTODOS = "SELECT * FROM disco";

	private static final String MOSTRARPORNOMBRE = "SELECT *  FROM disco WHERE nombre=?";
	private static final String MOSTRARPORID = "SELECT *  FROM disco WHERE id=?";

	private static final String EDITAR = "UPDATE disco SET nombre=?, fecha_publicacion=?, foto=? WHERE id=?";
	private static final String BORRAR = "DELETE FROM disco WHERE id=?";

	private static Connection con = null;

	public DiscoDAO() {
		super();
	}

	public DiscoDAO(String nombre, LocalDate fecha_publicacion, String foto, int n_Reproduciones, int id,
			Artista id_Artista) {
		super(nombre, fecha_publicacion, foto, n_Reproduciones, id, id_Artista);
	}

	public DiscoDAO(Disco d) {
		super(d.getNombre(), d.getFecha_publicacion(), d.getFoto(), d.getN_Reproduciones(), d.getId(),
				d.getId_Artista());
	}

	public void guardar() {
		System.out.println("Inicio de guardar");
			con = MariaDBConexion.getConexion();
			if (con != null) {
				PreparedStatement ps = null;
				ResultSet rs = null;
				try {
					ps = con.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);
					System.out.println(this.Nombre);
					ps.setString(1, this.Nombre);
					ps.setDate(2, Date.valueOf(this.Fecha_publicacion));
					System.out.println(this.Fecha_publicacion);
					ps.setString(3, this.Foto);
					System.out.println(this.Foto);
					ps.setInt(4, this.N_Reproduciones);
					System.out.println(this.N_Reproduciones);
					ps.setInt(5, this.id_Artista.getId());
					System.out.println(this.id_Artista);
					System.out.println("Awui");
					ps.executeUpdate();
					// Solo lo puedes ejecutar si has puesto RETURN_GENERATED_KEYS
					rs = ps.getGeneratedKeys();
					System.out.println("uuuuuuuu");
					if (rs.next()) {
						this.id = rs.getInt(1);
					}
					// fin de extraer el id generado automaticamente en la db
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					try {
						ps.close();
						rs.close();
					} catch (SQLException e) {
						// TODO: handle exception
					}
				}
			}
		
	}

	public void editar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(EDITAR);

				ps.setString(1, this.Nombre);
				ps.setDate(2, Date.valueOf(this.Fecha_publicacion));
				ps.setString(3, this.Foto);
				ps.setInt(4, this.N_Reproduciones);
				ps.setInt(5, this.id_Artista.getId());

				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void borrar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(BORRAR);
				ps.setInt(1, this.id);
				ps.executeUpdate();
				this.id = -1;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public static Disco mostrarPorID(int id) {
		Disco resultado = new DiscoDAO();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORID);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					ArtistaDAO x = new ArtistaDAO();
					Artista xs = x.mostrarPorID(rs.getInt("Id_artista"));
					resultado = (new Disco(

							rs.getString("Nombre"), rs.getDate("FechaPublicacion").toLocalDate(), rs.getString("foto"),
							rs.getInt("NumeroReproducciones"), xs

					));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

		return resultado;
	}

	public static Disco mostrarPorNombre(String nombre) {
		Disco resultado = new DiscoDAO();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORNOMBRE);
				ps.setString(1, nombre);
				rs = ps.executeQuery();

				while (rs.next()) {

					ArtistaDAO x = new ArtistaDAO();
					Artista xs = x.mostrarPorID(rs.getInt("Id_artista"));
					resultado = (new Disco(

							rs.getString("Nombre"), rs.getDate("FechaPublicacion").toLocalDate(), rs.getString("foto"),
							rs.getInt("NumeroReproducciones"), xs

					));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

		return resultado;
	}

	public static List<Disco> mostrarTodos() {
		List<Disco> resultado = new ArrayList<Disco>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARTODOS);
				rs = ps.executeQuery();

				while (rs.next()) {

					ArtistaDAO x = new ArtistaDAO();
					Artista xs = x.mostrarPorID(rs.getInt("Id_artista"));
					resultado.add(new Disco(

							rs.getString("Nombre"), rs.getDate("FechaPublicacion").toLocalDate(), rs.getString("foto"),
							rs.getInt("NumeroReproducciones"), xs

					));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}

}
