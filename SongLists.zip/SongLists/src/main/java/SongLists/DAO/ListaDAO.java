package SongLists.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.MariaDBConexion;
import SongList.Utils.Utils;
import SongLists.model.Lista;
import SongLists.model.Usuario;
import SongLists.model.usuario_lista;
import javafx.fxml.FXML;

public class ListaDAO extends Lista {
	private static final String INSERT = "INSERT INTO lista " + "(Nombre, Descripcion, Creador) VALUES (?,?,?)";

	private static final String MOSTRARTODOS = "SELECT Nombre, Descripcion, Creador,id FROM lista ";
	private static final String MOSTRARPORNOMBRE = "SELECT Nombre, Descripcion, Creador,id  FROM lista WHERE nombre=?";
	private static final String MOSTRARPORID = "SELECT Nombre, Descripcion, Creador,id   FROM lista WHERE id=?";

	private static final String EDITAR = "UPDATE lista SET Nombre=?, Descripcion=?, Creador=? WHERE id=?";
	private static final String BORRAR = "DELETE FROM lista WHERE id=?";

	private static Connection con = null;

	public ListaDAO() {
		super();
	}

	public ListaDAO(String nombre, String descripcion, Usuario creador, int id) {
		super(nombre, descripcion, creador, id);
	}

	public ListaDAO(Lista a) {
		super(a.getNombre(), a.getDescripcion(), a.getCreador(), a.getID());
	}

	public void guardar() {
		
			con = MariaDBConexion.getConexion();
			if (con != null) {
				PreparedStatement ps = null;
				ResultSet rs = null;
				try {
					ps = con.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS);

					ps.setString(1, this.Nombre);
					ps.setString(2, this.Descripcion);
					ps.setString(3, this.creador.getNombre());
					ps.executeUpdate();
					// Solo lo puedes ejecutar si has puesto RETURN_GENERATED_KEYS
					rs = ps.getGeneratedKeys();
					if (rs.next()) {
						this.id = rs.getInt(1);
					}
					// fin de extraer el id generado automaticamente en la db
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					try {
						ps.close();
						rs.close();
					} catch (SQLException e) {
						// TODO: handle exception
					}
				}
			}
		
	}

	public void editar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(EDITAR);

				ps.setString(1, this.Nombre);
				ps.setString(2, this.Descripcion);
				ps.setString(3, this.creador.getNombre());

				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void borrar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(BORRAR);
				ps.setInt(1, this.id);
				ps.executeUpdate();
				this.id = -1;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public static List<Lista> mostrarTodos() {
		List<Lista> resultado = new ArrayList<Lista>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARTODOS);
				rs = ps.executeQuery();

				while (rs.next()) {

					UsuarioDAO x = new UsuarioDAO();
					Usuario xs = x.MostrarNombre(rs.getString("creador"));
					resultado.add(new Lista(

							rs.getString("Nombre"), rs.getString("Descripcion"), xs, rs.getInt("id")));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}

	public static Lista mostrarPorNombre(String nombre) {
		Lista resultado = new Lista();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORNOMBRE);
				ps.setString(1, nombre);
				rs = ps.executeQuery();

				while (rs.next()) {

					UsuarioDAO x = new UsuarioDAO();
					Usuario xs = x.MostrarNombre(rs.getString("creador"));
					resultado = new Lista(

							rs.getString("Nombre"), rs.getString("Descripcion"), xs, rs.getInt("id")

					);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}

	public static Lista mostrarPorId(int id) {
		Lista resultado = new Lista();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORID);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					UsuarioDAO x = new UsuarioDAO();
					Usuario xs = x.MostrarNombre(rs.getString("creador"));
					resultado = new Lista(

							rs.getString("Nombre"), rs.getString("Descripcion"), xs, rs.getInt("id")

					);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}
	public static List<Lista> Mostrar_Favoritos(){
		
		List<Lista> resultado= new ArrayList<Lista>();
		List<usuario_lista> listas_usuario= usuario_listaDAO.mostrarPorIdUsuario(Utils.logueado.getID());
		
		for (int i = 0; i < listas_usuario.size(); i++) {
			resultado.add(ListaDAO.mostrarPorId(listas_usuario.get(i).getId_Lista()));
			
		}
		
		return resultado;
		
	}
	
}
