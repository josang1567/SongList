package SongLists.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.MariaDBConexion;
import SongLists.model.Lista;
import SongLists.model.usuario_lista;

public class usuario_listaDAO extends usuario_lista {

	private static final String INSERT = "INSERT INTO usuario_lista(nombre_usuario, Id_usuario, nombre_lista, Id_Lista) VALUES (?,?,?,?)";

	private static final String MOSTRARTODOS = "SELECT nombre_usuario, Id_usuario, nombre_lista, Id_Lista FROM usuario_lista ";
	private static final String MOSTRARPORNOMBRE = "SELECT nombre_usuario, Id_usuario, nombre_lista, Id_Lista FROM usuario_lista WHERE Nombre_Lista=?";
	private static final String MOSTRARPORIDLISTA = "SELECT nombre_usuario, Id_usuario, nombre_lista, Id_Lista FROM usuario_lista WHERE Id_Lista=?";
	private static final String MOSTRARPORIDUSUARIO = "SELECT nombre_usuario, Id_usuario, nombre_lista, Id_Lista FROM usuario_lista WHERE Id_usuario=?";

	private static final String EDITAR = "UPDATE usuario_lista SET nombre_usuario=?,Id_usuario=?,nombre_lista=?,Id_Lista=? WHERE Id_Lista=?";
	private static final String BORRAR = "DELETE FROM usuario_lista WHERE Id_Lista=?";
	private static Connection con = null;
	
	
	
	public void guardar() {
//nombre_usuario, Id_usuario, nombre_lista, Id_Lista
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
		
			try {
				ps = con.prepareStatement(INSERT);

				ps.setString(1, this.nombre_lista);
				ps.setInt(2, this.Id_Lista);
				ps.setString(3, this.nombre_usuario);
				ps.setInt(4, this.Id_usuario);
				ps.executeUpdate();
				
				
				// fin de extraer el id generado automaticamente en la db
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void editar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(EDITAR);

				ps.setString(1, this.nombre_lista);
				ps.setInt(2, this.Id_Lista);
				ps.setString(3, this.nombre_usuario);
				ps.setInt(4, this.Id_usuario);

				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public void borrar() {
		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			try {
				ps = con.prepareStatement(BORRAR);
				ps.setInt(1, this.Id_usuario);
				ps.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}

	}

	public static List<usuario_lista> mostrarTodos() {
		List<usuario_lista> resultado = new ArrayList<usuario_lista>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARTODOS);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new usuario_lista(

							rs.getString("Nombre_Lista"),
							rs.getString("Nombre_cancion"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_usuario")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}

	public static List<usuario_lista> mostrarPorNombre(String nombre) {
		List<usuario_lista> resultado = new ArrayList<usuario_lista>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORNOMBRE);
				ps.setString(1, nombre);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new usuario_lista(

							rs.getString("Nombre_Lista"),
							rs.getString("nombre_usuario"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	
	}

	public static  List<usuario_lista> mostrarPorIdlista(int id) {
		List<usuario_lista> resultado = new ArrayList<usuario_lista>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORIDLISTA);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new usuario_lista(

							rs.getString("Nombre_Lista"),
							rs.getString("nombre_usuario"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_cancion")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}
	
	
	public static  List<usuario_lista> mostrarPorIdUsuario(int id) {
		List<usuario_lista> resultado = new ArrayList<usuario_lista>();

		con = MariaDBConexion.getConexion();
		if (con != null) {
			PreparedStatement ps = null;
			ResultSet rs = null;
			try {
				ps = con.prepareStatement(MOSTRARPORIDUSUARIO);
				ps.setInt(1, id);
				rs = ps.executeQuery();

				while (rs.next()) {

					resultado.add(new usuario_lista(

							rs.getString("Nombre_Lista"),
							rs.getString("nombre_usuario"),
							rs.getInt("Id_Lista"),
							rs.getInt("Id_usuario")
							
							
							));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					ps.close();
					rs.close();
				} catch (SQLException e) {
					// TODO: handle exception
				}
			}
		}
		return resultado;
	}
	
}
