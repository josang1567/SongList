package SongLists.model;

public class Lista_cancion {

	protected String Nombre_Lista,  Nombre_cancion ;
	protected int Id_Lista, Id_cancion;
	
	public Lista_cancion(String nombre_Lista, String nombre_cancion, int id_Lista, int id_cancion) {
		super();
		Nombre_Lista = nombre_Lista;
		Nombre_cancion = nombre_cancion;
		Id_Lista = id_Lista;
		Id_cancion = id_cancion;
	}
	
	public Lista_cancion() {
		super();
	}

	public String getNombre_Lista() {
		return Nombre_Lista;
	}

	public void setNombre_Lista(String nombre_Lista) {
		Nombre_Lista = nombre_Lista;
	}

	public String getNombre_cancion() {
		return Nombre_cancion;
	}

	public void setNombre_cancion(String nombre_cancion) {
		Nombre_cancion = nombre_cancion;
	}

	public int getId_Lista() {
		return Id_Lista;
	}

	public void setId_Lista(int id_Lista) {
		Id_Lista = id_Lista;
	}

	public int getId_cancion() {
		return Id_cancion;
	}

	public void setId_cancion(int id_cancion) {
		Id_cancion = id_cancion;
	}
	
	
}
