package SongLists.model;

public class usuario_lista {
	protected String nombre_usuario, nombre_lista;
	protected int Id_usuario, Id_Lista;

	
	public usuario_lista(String nombre_usuario, String nombre_lista, int id_usuario, int id_Lista) {
		super();
		this.nombre_usuario = nombre_usuario;
		this.nombre_lista = nombre_lista;
		Id_usuario = id_usuario;
		Id_Lista = id_Lista;
	}

	public usuario_lista() {
		super();
	}
	
	public String getNombre_usuario() {
		return nombre_usuario;
	}

	public void setNombre_usuario(String nombre_usuario) {
		this.nombre_usuario = nombre_usuario;
	}

	public String getNombre_lista() {
		return nombre_lista;
	}

	public void setNombre_lista(String nombre_lista) {
		this.nombre_lista = nombre_lista;
	}

	public int getId_usuario() {
		return Id_usuario;
	}

	public void setId_usuario(int id_usuario) {
		Id_usuario = id_usuario;
	}

	public int getId_Lista() {
		return Id_Lista;
	}

	public void setId_Lista(int id_Lista) {
		Id_Lista = id_Lista;
	}

	

}
