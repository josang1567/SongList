package SongLists;

import javafx.fxml.FXML;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import SongList.Utils.Utils;
import SongLists.DAO.CancionDAO;
import SongLists.DAO.ListaDAO;
import SongLists.DAO.Lista_cancionDAO;
import SongLists.DAO.usuario_listaDAO;
import SongLists.model.Lista;
import SongLists.model.usuario_lista;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;

public class V_ListaController {
	static ListaDAO lista = new ListaDAO();
	static List<Lista> listas = new ArrayList<Lista>();

	@FXML
	private Label nombre;
	@FXML
	private Label descripcion;
	@FXML
	private Button id;
	@FXML
	private Label creador;
	@FXML
	private TableView<Lista> tablaArtistas;
	@FXML
	private TableColumn<Lista, String> ArtistaColumna;
	@FXML
	private Menu menu;
	@FXML
	protected void initialize() {
		
		
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
		
		List<Lista> Listado = new ArrayList<Lista>();
		muestraInfo(null);
		configuraTabla();
		switch (Utils.tipopestaña) {
		case "todos":
			Listado = ListaDAO.mostrarTodos();
			break;
		case "ID":
			Listado.add(ListaDAO.mostrarPorId((int) Utils.dato));
			break;
		case "nombre":
			Listado.add(ListaDAO.mostrarPorNombre((String) Utils.dato));
			break;
		case "favorito":
			
			Listado=ListaDAO.Mostrar_Favoritos();
			break;
		default:
			break;

		}
		tablaArtistas.setItems(FXCollections.observableArrayList(Listado));
		tablaArtistas.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			muestraInfo(newValue);
		});
	}

	private void muestraInfo(Lista a) {
		if (a != null) {
			nombre.setText(a.getNombre());
			descripcion.setText(a.getDescripcion());
			id.setText(String.valueOf(a.getID()));
			creador.setText(a.getCreador().getNombre());
		} else {
			nombre.setText("Desconocido");
			descripcion.setText("Desconocido");
			id.setText("Desconocido");
			creador.setText("desconocido");
		}
	}

	private void configuraTabla() {
		ArtistaColumna.setCellValueFactory(cadaArtista -> {
			SimpleStringProperty v = new SimpleStringProperty();
			v.setValue(cadaArtista.getValue().getNombre());
			return v;
		});

	}
	
	
	
	
	@FXML
	private void Subscribe() throws IOException {
		usuario_listaDAO nuevaAdicion = new usuario_listaDAO();
		nuevaAdicion.setId_Lista(Integer.parseInt(id.getText()));
		nuevaAdicion.setId_usuario(Utils.logueado.getID());
		nuevaAdicion.setNombre_lista(nombre.getText());
		nuevaAdicion.setNombre_usuario(Utils.logueado.getNombre());
		
		nuevaAdicion.guardar();
		
		App.setRoot("V_Lista");
	}
	
	@FXML
	private void SwitchToFavorites()throws IOException {
		Utils.tipopestaña="favorito";
		App.setRoot("V_Lista");
	}
	@FXML
	private void SwitchToCancionesDeLista()  throws IOException{
		System.out.println(id.getText());
		Utils.dato=id.getText();
		System.out.println(Utils.dato);
		App.setRoot("V_Disco");
		
	}
	@FXML
	private void eliminar() throws IOException {
		if(Utils.tipopestaña=="favorito"){
			usuario_listaDAO nuevaAdicion = new usuario_listaDAO();
			nuevaAdicion.setId_Lista(Integer.parseInt(id.getText()));
			nuevaAdicion.setId_usuario(Utils.logueado.getID());
			nuevaAdicion.setNombre_lista(nombre.getText());
			nuevaAdicion.setNombre_usuario(Utils.logueado.getNombre());
			nuevaAdicion.borrar();
		}else {
			lista.borrar();
		}
		App.setRoot("V_Artista");
	}
	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("E_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("V_Usuarios");
	}
	
	
}
