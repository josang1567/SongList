package SongLists;
import javafx.fxml.FXML;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.DiscoDAO;
import SongLists.model.Disco;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
public class V_DiscoController {

	
	static DiscoDAO disco = new DiscoDAO();
	static List<Disco> discos = new ArrayList<Disco>();
	@FXML
	private Label nombre;
	@FXML
	private Label Fecha;
	@FXML
	private ImageView fotoview;
	@FXML
	private Label NumeroReproducciones;
	@FXML
	private Label id;
	@FXML
	private Menu menu;
	@FXML
	private Button id_artista;
	@FXML
	private TableView<Disco> tablaDiscos;
	@FXML
	private TableColumn<Disco, String> DiscoColumna;

	@FXML
	protected void initialize() {
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
		List<Disco> Listado = new ArrayList<Disco>();
		muestraInfo(null);
		configuraTabla();
		switch (Utils.tipopestaña) {
		case "todos":
			Listado = DiscoDAO.mostrarTodos();
			break;
		case "ID":
			Listado.add(DiscoDAO.mostrarPorID((int) Utils.dato));
			break;
		case "nombre":
			Listado.add(DiscoDAO.mostrarPorNombre((String) Utils.dato));
			break;
		default:
			break;

		}
		tablaDiscos.setItems(FXCollections.observableArrayList(Listado));
		tablaDiscos.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			muestraInfo(newValue);
		});
	}
	
	@FXML
	private void VerDiscosDeArtista()throws IOException {
		Utils.tipopestaña="id";
		Utils.dato=id_artista.getText();
		App.setRoot("V_Artista");
	}
	
	private void muestraInfo(Disco d) {
		if (d != null) {
			nombre.setText(d.getNombre()); 
			Fecha.setText(String.valueOf(d.getFecha_publicacion()));
			File foto = new File("file:" + d.getFoto());
			Image aFoto = new Image(foto.getPath());
			fotoview.setImage(aFoto);
			NumeroReproducciones.setText(String.valueOf(d.getN_Reproduciones()));
			 id.setText(String.valueOf(d.getId()));
			id_artista.setText(String.valueOf(d.getId_Artista().getId()));
		} else {
			nombre.setText("Desconocido"); 
			Fecha.setText("Desconocido");
			NumeroReproducciones.setText("Desconocido");
			 id.setText("Desconocido");
			id_artista.setText("Desconocido");
			
		}
	}

	private void configuraTabla() {
		DiscoColumna.setCellValueFactory(cadaArtista -> {
			SimpleStringProperty v = new SimpleStringProperty();
			v.setValue(cadaArtista.getValue().getNombre());
			return v;
		});

	}

	@FXML
	private void eliminar() throws IOException {
		disco.borrar();
		App.setRoot("V_Artista");
	}
	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("E_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("V_Usuarios");
	}
	
}
