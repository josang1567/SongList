package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.ArtistaDAO;
import SongLists.model.Artista;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;

public class V_ArtistaController {
	static ArtistaDAO artista = new ArtistaDAO();
	static List<Artista> artistas = ArtistaDAO.mostrarTodos();
	@FXML
	private Label nombre;
	@FXML
	private Label Nacionalidad;
	@FXML
	private ImageView fotoview;
	@FXML
	private Button id;
	@FXML
	private TableView<Artista> tablaArtistas;
	@FXML
	private TableColumn<Artista, String> ArtistaColumna;
	@FXML
	private Menu menu;
	@FXML
	protected void initialize() {
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
		
		List<Artista> Listado = new ArrayList<Artista>();
		muestraInfo(null);
		configuraTabla();
		switch (Utils.tipopestaña) {
		case "todos":
			Listado = ArtistaDAO.mostrarTodos();
			break;
		case "ID":
			Listado.add(ArtistaDAO.mostrarPorID((int) Utils.dato));
			break;
		case "nombre":
			Listado.add(ArtistaDAO.mostrarPorNombre((String) Utils.dato));
			break;
		default:
			break;

		}
		tablaArtistas.setItems(FXCollections.observableArrayList(Listado));
		tablaArtistas.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			muestraInfo(newValue);
		});
	}

	private void muestraInfo(Artista a) {
		if (a != null) {
			nombre.setText(a.getNombre());
			Nacionalidad.setText(a.getNacionalidad());
			id.setText(String.valueOf(a.getId()));
			File foto = new File( a.getFoto());
			Image aFoto = new Image("file:" +foto.getPath());
			fotoview.setImage(aFoto);
		} else {
			nombre.setText("Desconocido");
			Nacionalidad.setText("Desconocido");
			id.setText("Desconocido");
		}
	}

	private void configuraTabla() {
		ArtistaColumna.setCellValueFactory(cadaArtista -> {
			SimpleStringProperty v = new SimpleStringProperty();
			v.setValue(cadaArtista.getValue().getNombre());
			return v;
		});

	}

	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("E_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("V_Usuarios");
	}
	@FXML
	private void eliminar() throws IOException {
		artista.borrar();
		App.setRoot("V_Artista");
	}
}
