package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.ArtistaDAO;
import SongLists.DAO.DiscoDAO;
import SongLists.model.Artista;
import SongLists.model.Disco;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class E_DiscoController {
	static DiscoDAO nuevo = new DiscoDAO();
	static List<Disco> todosDiscos = DiscoDAO.mostrarTodos();
	static String direccionurl = "src/main/resources/Imagenes/portadas/";
	static String camposFaltantes = "";

	@FXML
	private TextField nombre;
	@FXML
	private DatePicker fecha;
	
	@FXML
	private ComboBox<String> ArtistaBox;
	@FXML
	private ImageView fotoview;
	@FXML
	private TextField urltext;
	@FXML
	private Button seleccionarFoto;
	
	@FXML
	private ComboBox<String> nombrebox;
	@FXML
	private void initialize() {
		
		List<Artista> todos=ArtistaDAO.mostrarTodos();
		if (urltext.getText().trim().equals("")) {
			urltext.setText("../Imagenes/Logo/634741.png");
		}
		
		ObservableList<String>listaArtistas=FXCollections.observableArrayList(nombresArtistas(ArtistaDAO.mostrarTodos()));
		ArtistaBox.setValue(listaArtistas.get(0));
		ArtistaBox.setItems(listaArtistas);
		if(todos.size()>3) {
			ArtistaBox.setVisibleRowCount(3);
		}
		
		ObservableList<String> listaNombres= FXCollections.observableArrayList(nombres((DiscoDAO.mostrarTodos())));
		nombrebox.setValue(listaNombres.get(0));
		nombrebox.setItems(listaNombres);
		if((DiscoDAO.mostrarTodos()).size()>3) {
			nombrebox.setVisibleRowCount(3);
		}
	
	}
	private ArrayList<String>nombresArtistas(List<Artista> d){
		ArrayList<String> artistas= new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			artistas.add(d.get(i).getNombre());
		}
		return artistas;
	}
	
	private ArrayList<String>nombres(List<Disco> d){
		ArrayList<String> nombres= new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			nombres.add(d.get(i).getNombre());
		}
		return nombres;
	}
	
	@FXML
	private void Agregar() throws IOException {
		
			if (!validarFormulario())
				return;
			nuevo.setNombre(nombre.getText());
			
			nuevo.setFecha_publicacion(fecha.getValue());
			
			Utils.saveImage(urltext.getText(), direccionurl + nuevo.getNombre());
			
			nuevo.setFoto(direccionurl +nuevo.getNombre() + ".jpg");
			
			nuevo.setId_Artista(ArtistaDAO.mostrarPorNombre(ArtistaBox.getValue()));
			try {
				
			} catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		System.out.println(nuevo);
		nuevo.setId(DiscoDAO.mostrarPorNombre(nombrebox.getValue()).getId());
		nuevo.editar();
		mostrarAlertInfo();
		App.setRoot("V_Disco");
	}

	@FXML
	private void Cancel() throws IOException{
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	
	
	private boolean validarFormulario() {
		boolean result = true;
		if (nombre.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "nombre\n";
		}
		
		if(ArtistaBox.getSelectionModel().getSelectedItem()==null) {
			result=false;
			camposFaltantes+="Artista\n";
		}
		if(result==false) {
			mostrarAlert();
		}
		return result;
	}
	@FXML
	private void selecImagen() {
		File file = null;
		FileChooser filechooser = new FileChooser();
		filechooser.setTitle("Selecionar imagen...");
		try {
			file = filechooser.showOpenDialog(null);
			if (file != null && file.getPath().matches(".+\\.png") || file.getPath().matches(".+\\.jpg")) {
				Image img = new Image("file:\\" + file.getPath());
				fotoview.setImage(img);
				urltext.setText(file.getPath());
			} else { // si la extension es incorrecta sale esta alerta
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Información");
				alert.setContentText("Formato incorrecto: Debe elegir un tipo de archivo jpg o png.");
				alert.showAndWait();
			}
		} catch (Exception e) {
			// TODO: handle exception;
		}
	}
	
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}

	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Disco guardado");
		alert.showAndWait();
	}

	private void mostrarAlertUsuario() {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("El usuario no existe");
		alert.showAndWait();
	}
}
