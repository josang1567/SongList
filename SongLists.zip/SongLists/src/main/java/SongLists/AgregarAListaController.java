package SongLists;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.CancionDAO;
import SongLists.DAO.ListaDAO;
import SongLists.DAO.Lista_cancionDAO;
import SongLists.model.Lista;
import SongLists.model.Lista_cancion;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.text.Text;

public class AgregarAListaController {

	@FXML
	private Text cancion;
	@FXML
	ComboBox<String> listado;

	@FXML
	private void initialize() {
		List<Lista> todos = ListaDAO.mostrarTodos();
		cancion.setText(CancionDAO.mostrarPorNombre((String) Utils.dato).getNombre());
		ObservableList<String> listaListas = FXCollections.observableArrayList(nombresListas(ListaDAO.mostrarTodos()));
		listado.setValue(listaListas.get(0));
		listado.setItems(listaListas);
		if (todos.size() > 3) {

		}

	}

	private ArrayList<String> nombresListas(List<Lista> d) {
		ArrayList<String> listas = new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			listas.add(d.get(i).getNombre());
		}
		return listas;
	}

	@FXML
	private void agregar() throws IOException{
		Lista_cancionDAO nuevaAdicion= new Lista_cancionDAO();
		
		nuevaAdicion.setId_cancion((int) Utils.dato);
		nuevaAdicion.setId_Lista(ListaDAO.mostrarPorNombre(listado.getValue()).getID());
		nuevaAdicion.setNombre_cancion(CancionDAO.mostrarPorId((int)Utils.dato).getNombre());
		nuevaAdicion.setNombre_Lista(ListaDAO.mostrarPorNombre(listado.getValue()).getNombre());
		
		nuevaAdicion.guardar();
	}
	
	
	@FXML
	private void Cancel() throws IOException {
		Utils.tipopestaña = "todos";
		App.setRoot("V_Cancion");
	}
}
