package SongLists;

import java.io.IOException;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.ListaDAO;
import SongLists.model.Lista;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class C_ListaController {
	static ListaDAO nuevo = new ListaDAO();
	static List<Lista> todasListas = ListaDAO.mostrarTodos();
	static String direccionurl = "src/main/resources/Imagenes/portadas/";
	static String camposFaltantes = "";

	@FXML
	private TextField nombretext;
	@FXML
	private TextArea descripcion;

	@FXML
	private void Agregar() throws IOException {
		try {
			if (!validarFormulario())
				return;
			nuevo.setNombre(nombretext.getText());
			nuevo.setDescripcion(descripcion.getText());
			nuevo.setCreador(Utils.logueado);
			nuevo.guardar();
		} catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		
		App.setRoot("V_Lista");
		
	}

	private boolean validarFormulario() {
		boolean result = true;
		if (nombretext.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "nombre\n";
		}
		if (descripcion.getText().trim().equals("")) {
			result = false;
			camposFaltantes += "descripcion\n";
		}
		if(result==false) {
			mostrarAlert();
		}
		return result;
	}

	@FXML
	private void Cancel() throws IOException{
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}

	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Lista guardada");
		alert.showAndWait();
	}

	private void mostrarAlertUsuario() {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("La Lista no existe");
		alert.showAndWait();
	}
}
