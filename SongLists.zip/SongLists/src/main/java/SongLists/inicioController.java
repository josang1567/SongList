package SongLists;

import java.io.IOException;

import SongList.Utils.Utils;
import javafx.fxml.FXML;
import javafx.scene.control.Menu;

public class inicioController {
	@FXML
	private Menu menu;
	
	@FXML
	protected void initialize() {
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
	}
	
	
	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Usuarios");
	}

}
