package SongLists;

import java.io.IOException;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.UsuarioDAO;
import SongLists.model.Usuario;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {
	static List<Usuario> todosUsuarios ;
	static String direccionurl = "src/main/resources/Imagenes/portadas/";
	static String camposFaltantes = "";
	@FXML
	private TextField nombretext;
	@FXML
	private PasswordField Contraseñatext;
	
	@FXML
	private void iniciarSesion()throws IOException{
		todosUsuarios=UsuarioDAO.mostrarTodos();
		System.out.println(todosUsuarios);
		
		
		
		if(!validarFormulario())
			return;
		if(!comprobarExistencia()) 
			return;
		
		

		App.setRoot("Inicio");
	}
	@FXML
	private void Register() throws IOException {
		App.setRoot("Registro");
	}
	private boolean validarFormulario() {
		boolean result = true;
		
		if (nombretext.getText().matches("")) {
			result = false;
			
			camposFaltantes += "Usuario\n";
		}

		if (Contraseñatext.getText().matches("")) {
			result = false;
			
			camposFaltantes += "Contraseña\n";
		}
	
		
		// en caso de faltar algo muestra un aviso
		if (!result ) {
			mostrarAlert();
		}
		
		return result;
	}
	
	
	private boolean comprobarExistencia() {
		boolean existe=false;
		todosUsuarios=UsuarioDAO.mostrarTodos();
		for (int i = 0; i < todosUsuarios.size()&&existe==false; i++) {
			if((nombretext.getText().matches(todosUsuarios.get(i).getNombre()))	
			&&(Contraseñatext.getText().matches(todosUsuarios.get(i).getContraseña()))) {
				
				existe=true;
				Utils.logueado=todosUsuarios.get(i);
				System.out.println("Usuario actualmente Logueado: "+Utils.logueado);
			}
		}
		if(!existe) {
			mostrarAlertUsuario();
		}
		return existe;
	}
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}
	private void mostrarAlertUsuario() {
		Alert alert = new Alert(Alert.AlertType.WARNING);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("El usuario no existe");
		alert.showAndWait();
	}
}
