package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import SongList.Utils.Utils;
import SongLists.DAO.ArtistaDAO;
import SongLists.DAO.DiscoDAO;
import SongLists.DAO.ListaDAO;
import SongLists.DAO.UsuarioDAO;
import SongLists.model.Lista;
import SongLists.model.Usuario;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class E_UsuarioController {
	
	static UsuarioDAO uD= new UsuarioDAO();
	static String direccionurl="src/main/resources/Imagenes/portadas/";
	static List<String> camposFaltantes = new ArrayList<String>();
	@FXML
	private TextField nombretext;
	@FXML
	private TextField correotext;
	
	@FXML
	private PasswordField contraseña1text;
	
	@FXML
	private PasswordField contraseña2text;
	@FXML
	private ImageView fotoview;
	@FXML
	private TextField urltext;
	@FXML
	private Button seleccionarFoto;

	@FXML
	private ComboBox<String> nombrebox;
	
	@FXML
	private void Cancel() throws IOException{
		Utils.tipopestaña="todos";
		App.setRoot("V_Usuarios");
	}
	@FXML
	private void initialize() {
		ObservableList<String> listaNombres= FXCollections.observableArrayList(nombres((UsuarioDAO.mostrarTodos())));
		nombrebox.setValue(listaNombres.get(0));
		nombrebox.setItems(listaNombres);
		if((DiscoDAO.mostrarTodos()).size()>3) {
			nombrebox.setVisibleRowCount(3);
		}
	}
	
	private ArrayList<String>nombres(List<Usuario> d){
		ArrayList<String> nombres= new ArrayList<String>();
		for (int i = 0; i < d.size(); i++) {
			nombres.add(d.get(i).getNombre());
		}
		return nombres;
	}
	@FXML
	//metodo del metodo de agregar
	private void switchtousuarios() throws IOException{
		if(!validarFormulario()) 
			return;
		uD.setNombre(nombretext.getText());
		uD.setCorreo(correotext.getText());
		uD.setContraseña(contraseña1text.getText());
		Utils.saveImage(urltext.getText(),direccionurl+uD.getNombre());
		uD.setFoto(direccionurl+uD.getNombre()+".jpg");
		
		try {
			
		}catch(Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		uD.setID(UsuarioDAO.MostrarNombre(nombrebox.getValue()).getID());
		uD.editar();
		
		mostrarAlertInfo();
		Utils.tipopestaña="todos";
		App.setRoot("Login");
		
	}
	
	private boolean validarFormulario() {
		boolean result = true;
		
		if (nombretext.getText().trim().equals("")) {
			result = false;
			camposFaltantes.add("nombre");
		}
		if (correotext.getText().trim().equals("")) {
			result = false;
			camposFaltantes.add("Correo");
		}
		if (contraseña1text.getText().trim().equals("")) {
			result = false;
			camposFaltantes.add("contraseña 1");
		}
		if (contraseña2text.getText().trim().equals("")) {
			result = false;
			camposFaltantes.add("contraseña 2");
		}
		
		if (contraseña1text.getText().trim()!=contraseña2text.getText().trim()) {
			result = false;
			camposFaltantes.add("Las contraseñas no coinciden");
		}
		
		mostrarAlert();
		return result;
	}
	@FXML
	private void selecImagen() {
		File file = null;
		FileChooser filechooser = new FileChooser();
		filechooser.setTitle("Selecionar imagen...");
		try {
			file = filechooser.showOpenDialog(null);
			if (file != null && file.getPath().matches(".+\\.png") || file.getPath().matches(".+\\.jpg")) {
				Image img = new Image("file:\\" + file.getPath());
				fotoview.setImage(img);
				urltext.setText(file.getPath());
			} else { // si la extension es incorrecta sale esta alerta
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Información");
				alert.setContentText("Formato incorrecto: Debe elegir un tipo de archivo jpg o png.");
				alert.showAndWait();
			}
		} catch (Exception e) {
			// TODO: handle exception;
		}
	}
	
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}
	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Usuario guardado");
		alert.showAndWait();
	}

}

