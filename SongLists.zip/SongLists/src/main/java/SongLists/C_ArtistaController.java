package SongLists;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import SongList.Utils.Utils;
import SongLists.DAO.ArtistaDAO;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class C_ArtistaController {

	static ArtistaDAO nuevo = new ArtistaDAO();
	static String direccionurl = "src/main/resources/Imagenes/Logo/";
	static String camposFaltantes = "";

	@FXML
	private TextField nombretext;
	@FXML
	private TextField nacionalidadtext;
	@FXML
	private ImageView fotoview;
	@FXML
	private TextField urltext;
	@FXML
	private Button seleccionarFoto;
	@FXML
	private ImageView cancelar;

	@FXML
	private void Cancel() throws IOException {
		Utils.tipopestaña = "todos";
		App.setRoot("V_Artista");
	}

	@FXML
	private void initialize() {
		if (urltext.getText().trim().equals("")) {
			urltext.setText("../Imagenes/Logo/634741.png");
		}
	}

	@FXML
	private void Agregar() throws IOException {

		try {
			if (!validarFormulario())
				return;
			nuevo.setNombre(nombretext.getText());
			nuevo.setNacionalidad(nacionalidadtext.getText());
			Utils.saveImage(urltext.getText(), direccionurl + nuevo.getNombre()+".jpg");
			nuevo.setFoto(direccionurl +nuevo.getNombre() + ".jpg");
		
		} catch (Exception e) {
			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setTitle("Alert");
			alert.setContentText("ERROR AL GUARDAR");
			alert.showAndWait();
		}
		nuevo.guardar();
		mostrarAlertInfo();
		Utils.tipopestaña = "todos";
		App.setRoot("V_Artista");
	}

	private boolean validarFormulario() {
		boolean result = true;

		if (nombretext.getText().trim().equals("")) {
			result = false;
			camposFaltantes+="nombre\n";
		}
		if (nacionalidadtext.getText().trim().equals("")) {
			result = false;
			camposFaltantes+="Correo\n";
		}

		if (result == false) {
			mostrarAlert();
		}

		return result;
	}
	@FXML
	private void selecImagen() {
		File file = null;
		FileChooser filechooser = new FileChooser();
		filechooser.setTitle("Selecionar imagen...");
		try {
			file = filechooser.showOpenDialog(null);
			if (file != null && file.getPath().matches(".+\\.png") || file.getPath().matches(".+\\.jpg")) {
				Image img = new Image("file:\\" + file.getPath());
				fotoview.setImage(img);
				urltext.setText(file.getPath());
			} else { // si la extension es incorrecta sale esta alerta
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setHeaderText(null);
				alert.setTitle("Información");
				alert.setContentText("Formato incorrecto: Debe elegir un tipo de archivo jpg o png.");
				alert.showAndWait();
			}
		} catch (Exception e) {
			// TODO: handle exception;
		}
	}
	private void mostrarAlert() {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setHeaderText(null);
		alert.setTitle("Alert");
		alert.setContentText("Rellene todos los campos: " + camposFaltantes);
		alert.showAndWait();
	}

	private void mostrarAlertInfo() {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Info");
		alert.setContentText("Artista guardado");
		alert.showAndWait();
	}

}
