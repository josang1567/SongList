package SongLists;

import SongLists.DAO.UsuarioDAO;
import SongLists.model.Usuario;
import javafx.fxml.FXML;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import SongList.Utils.Utils;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;

public class V_UsuarioController {
	static UsuarioDAO usuario = new UsuarioDAO();
	static List<Usuario> usuarios= UsuarioDAO.mostrarTodos();
	
	@FXML
	private Label nombre;
	@FXML
	private Label correo;
	@FXML
	private ImageView fotoview;
	@FXML
	private Label id;
	@FXML
	private Label contraseña;
	@FXML
	private TableView<Usuario> tablaUsuarios;
	@FXML
	private TableColumn<Usuario, String> UsuarioColumna;
	@FXML
	private Menu menu;
	
	@FXML
	protected void initialize() {
		if(Utils.logueado.equals(Utils.Administrador)) {
			menu.setVisible(true);
		}
		List<Usuario> Listado = new ArrayList<Usuario>();
		muestraInfo(null);
		configuraTabla();
		switch (Utils.tipopestaña) {
		case "todos":
			Listado = UsuarioDAO.mostrarTodos();
			break;
		case "ID":
			Listado.add( UsuarioDAO.mostrarPorID((int) Utils.dato));
			break;
		case "nombre":
			Listado.add( UsuarioDAO.MostrarNombre((String) Utils.dato));
			break;
		default:
			break;

		}
		tablaUsuarios.setItems(FXCollections.observableArrayList(Listado));
		tablaUsuarios.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
			muestraInfo(newValue);});
	}

	private void muestraInfo(Usuario u) {
		if (u != null) {
			nombre.setText(u.getNombre());
			correo.setText(u.getCorreo());
			id.setText(String.valueOf(u.getID()));
			contraseña.setText(u.getContraseña());
			File foto = new File("file:" + u.getFoto());
			Image aFoto = new Image(foto.getPath());
			fotoview.setImage(aFoto);
		} else {
			nombre.setText("Desconocido");
			correo.setText("Desconocido");
			id.setText("Desconocido");
			contraseña.setText("Desconocido");
		}
	}

	private void configuraTabla() {
		UsuarioColumna.setCellValueFactory(cadaUsuario -> {
			SimpleStringProperty v = new SimpleStringProperty();
			v.setValue(cadaUsuario.getValue().getNombre());
			return v;
		});

	}
	@FXML
	private void Ir_Editar_Artista() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Artista");
	}
	@FXML
	private void Ir_Crear_Artista() throws IOException {
		App.setRoot("C_Artista");
	}
	@FXML
	private void Ir_Ver_Artistas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Artista");
	}
	
	@FXML
	private void Ir_Editar_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Disco");
	}
	@FXML
	private void Ir_Crear_discos() throws IOException {
		App.setRoot("C_Disco");
	}
	@FXML
	private void Ir_Ver_discos() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Disco");
	}
	@FXML
	private void Ir_Editar_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Lista");
	}
	@FXML
	private void Ir_Crear_Listas() throws IOException {
		App.setRoot("C_Lista");
	}
	@FXML
	private void Ir_Ver_Listas() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Lista");
	}
	@FXML
	private void Ir_Editar_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("E_Cancion");
	}
	@FXML
	private void Ir_Crear_Canciones() throws IOException {
		App.setRoot("C_Cancion");
	}
	@FXML
	private void Ir_Ver_Canciones() throws IOException {
		Utils.tipopestaña="todos";
		App.setRoot("V_Cancion");
	}
	@FXML
	private void Ir_Editar_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("E_Usuarios");
	}
	@FXML
	private void Ir_Crear_Usuarios() throws IOException {
		App.setRoot("C_Usuarios");
	}
	@FXML
	private void Ir_Ver_Usuarios() throws IOException {
		Utils.tipopestaña="Todos";
		App.setRoot("V_Usuarios");
	}
	@FXML
	private void eliminar() throws IOException{
		usuario.borrar();
		App.setRoot("V_Usuario");
	}
}
