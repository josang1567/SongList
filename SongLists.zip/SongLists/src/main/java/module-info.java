module SongLists {
    requires javafx.controls;
    requires javafx.fxml;
	requires java.sql;

    opens SongLists to javafx.fxml;
    exports SongLists;
}
